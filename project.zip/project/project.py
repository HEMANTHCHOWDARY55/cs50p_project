import json

def main():
    print("Welcome to the Personal Finance Tracker!")
    while True:
        print("\nChoose an option:")
        print("1. Add a transaction")
        print("2. View summary")
        print("3. Check savings goal")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            amount = float(input("Enter amount: "))
            category = input("Enter category (e.g., food, entertainment, bills): ")
            trans_type = input("Enter type (income/expense): ").lower()
            add_transaction(amount, category, trans_type)
        elif choice == "2":
            print(view_summary())
        elif choice == "3":
            goal = float(input("Enter your savings goal: "))
            print(calculate_savings(goal))
        elif choice == "4":
            print("Exiting the program.")
            break
        else:
            print("Invalid choice, please try again.")

def add_transaction(amount, category, trans_type):
    transaction = {"amount": amount, "category": category, "type": trans_type}

    try:
        with open("transactions.json", "r") as file:
            transactions = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        transactions = []

    transactions.append(transaction)

    with open("transactions.json", "w") as file:
        json.dump(transactions, file, indent=4)

def view_summary():
    try:
        with open("transactions.json", "r") as file:
            transactions = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return "No transactions found."

    summary = {"income": 0, "expense": 0, "categories": {}}

    for transaction in transactions:
        amount = transaction["amount"]
        trans_type = transaction["type"]
        category = transaction["category"]

        if trans_type == "income":
            summary["income"] += amount
        elif trans_type == "expense":
            summary["expense"] += amount
            if category in summary["categories"]:
                summary["categories"][category] += amount
            else:
                summary["categories"][category] = amount

    net_savings = summary["income"] - summary["expense"]
    summary_text = f"Total Income: {summary['income']}\n"
    summary_text += f"Total Expense: {summary['expense']}\n"
    summary_text += f"Net Savings: {net_savings}\n"
    summary_text += "Expenses by Category:\n"

    for cat, amount in summary["categories"].items():
        summary_text += f" - {cat}: {amount}\n"

    return summary_text

def calculate_savings(goal):
    try:
        with open("transactions.json", "r") as file:
            transactions = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return "No transactions found."

    total_income = sum([t["amount"] for t in transactions if t["type"] == "income"])
    total_expense = sum([t["amount"] for t in transactions if t["type"] == "expense"])
    net_savings = total_income - total_expense

    if net_savings >= goal:
        return f"Congratulations! You've met your savings goal with {net_savings} saved."
    else:
        deficit = goal - net_savings
        return f"You are {deficit} short of your savings goal. Keep saving!"

if __name__ == "__main__":
    main()
