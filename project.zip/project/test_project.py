import pytest
from project import add_transaction, view_summary, calculate_savings
import json
import os

# Helper function to reset transactions.json
def reset_transactions():
    if os.path.exists("transactions.json"):
        os.remove("transactions.json")

def test_add_transaction():
    reset_transactions()
    add_transaction(1000, "salary", "income")
    add_transaction(200, "groceries", "expense")

    with open("transactions.json", "r") as file:
        transactions = json.load(file)

    assert transactions == [
        {"amount": 1000, "category": "salary", "type": "income"},
        {"amount": 200, "category": "groceries", "type": "expense"}
    ]

def test_view_summary():
    reset_transactions()
    add_transaction(500, "freelance", "income")
    add_transaction(150, "dining", "expense")
    add_transaction(100, "transport", "expense")

    summary = view_summary()
    assert "Total Income: 500" in summary
    assert "Total Expense: 250" in summary
    assert "Net Savings: 250" in summary
    assert " - dining: 150" in summary
    assert " - transport: 100" in summary

def test_calculate_savings():
    reset_transactions()
    add_transaction(800, "salary", "income")
    add_transaction(300, "shopping", "expense")

    assert calculate_savings(400) == "Congratulations! You've met your savings goal with 500 saved."
    assert calculate_savings(600) == "You are 100 short of your savings goal. Keep saving!"
