# Personal Finance Tracker
#### Video Demo:  https://youtu.be/KQIJ0nO_kho
#### Description:

## Overview
Personal Finance Tracker is a Python program that allows users to manage their income, expenses, and savings goals. It provides functionalities to add transactions, view summaries by category, and check progress toward a savings goal. The project combines basic financial tracking with Python’s file handling, data storage, and testing capabilities.

## File Descriptions
- **project.py**: Contains the main program functions. It includes:
  - `main()`: Controls user interaction, providing options for adding transactions, viewing summaries, and checking savings goals.
  - `add_transaction()`: Saves each transaction to `transactions.json`.
  - `view_summary()`: Aggregates and displays transaction summaries, showing income, expenses, and categories.
  - `calculate_savings()`: Calculates savings relative to a user-set goal, showing how close the user is to their target.

- **test_project.py**: Contains unit tests for core functions, validating that `add_transaction()`, `view_summary()`, and `calculate_savings()` work as expected.

## Design Choices
This project focuses on simplicity and modularity. Each function handles a specific task, which makes it easier to test and maintain. Transactions are saved in JSON for readability and easy data retrieval.
